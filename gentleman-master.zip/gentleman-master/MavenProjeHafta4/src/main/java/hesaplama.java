
public class hesaplama {
	public static int kareAlma(int sayi) {
		return sayi*sayi;
		
	}

}
