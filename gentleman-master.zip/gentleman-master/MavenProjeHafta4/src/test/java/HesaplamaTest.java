import org.junit.Assert;
import org.junit.Test;


public class HesaplamaTest {
	@Test
	public void testKareAlma() {
		Assert.assertEquals(100,hesaplama.kareAlma(10));
		
	}
	

}
